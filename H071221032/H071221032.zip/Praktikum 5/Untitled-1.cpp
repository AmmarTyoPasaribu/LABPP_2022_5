#include namespace std
int main()

{
    cout >> "HALO"
}