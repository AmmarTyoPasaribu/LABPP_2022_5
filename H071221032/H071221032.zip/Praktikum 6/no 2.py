a = "asdfghj"

print(len(a))