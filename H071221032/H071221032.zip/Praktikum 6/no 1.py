x = input() + ".txt"
file1 = open(x, "w+")
a = file1.read()

y = input() + ".txt"
try:
    file2 = open(y, "w+")
    file2.write(a)
    b = file2.read()

    print("Berhasil")
except:
    print("Gagal")

file1.close()
file2.close()